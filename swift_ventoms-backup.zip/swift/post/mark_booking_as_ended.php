<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
 
include_once '../../../config/dbConnectionAllSet.php';
include_once '../models/appPost.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

// prepare product object
$post = new Post($db);
 
$post->currentBookingId = isset($_GET['currentBookingId']) ? $_GET['currentBookingId']: die();

if($post->mark_booking_as_ended()) {
    echo json_encode(
      array('message' => 'User Created')
    );
  } else {
    echo json_encode(
      array('message' => 'User Not Created')
    );
  }
  
  
?>







